--Creer par Thibaut Branlant L3 Informatique ULCO Calais
--1.1.1)
INSERT INTO EMPLOYE VALUES ('EMP1190','ROGER','Stéphane','362, rue stéphane-roger, Ardre');
INSERT INTO EMPLOYE VALUES ('EMP1401','ROUSELLE','Nicolas','397, rue noclas-rouselle, St-Omer');
-- rollback faire revenir en arriere 

--1.1.2)
INSERT INTO EMPLOYE VALUES ('EMP1190','ROGER','Stéphane','362, rue stéphane-roger, Ardre');
INSERT INTO EMPLOYE VALUES ('EMP1401','ROUSELLE','Nicolas','397, rue noclas-rouselle, St-Omer');
-- commit "enregistre" le travail effectué pour ne pas pouvoir rollbakc celui ci 

